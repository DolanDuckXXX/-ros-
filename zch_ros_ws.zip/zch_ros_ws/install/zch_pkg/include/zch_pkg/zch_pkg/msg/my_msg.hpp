// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__MY_MSG_HPP_
#define ZCH_PKG__MSG__MY_MSG_HPP_

#include "zch_pkg/msg/detail/my_msg__struct.hpp"
#include "zch_pkg/msg/detail/my_msg__builder.hpp"
#include "zch_pkg/msg/detail/my_msg__traits.hpp"
#include "zch_pkg/msg/detail/my_msg__type_support.hpp"

#endif  // ZCH_PKG__MSG__MY_MSG_HPP_
