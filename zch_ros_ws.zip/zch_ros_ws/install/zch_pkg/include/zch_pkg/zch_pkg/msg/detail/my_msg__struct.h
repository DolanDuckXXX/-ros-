// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__STRUCT_H_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/MyMsg in the package zch_pkg.
typedef struct zch_pkg__msg__MyMsg
{
  rosidl_runtime_c__String name;
  int32_t age;
  float score;
} zch_pkg__msg__MyMsg;

// Struct for a sequence of zch_pkg__msg__MyMsg.
typedef struct zch_pkg__msg__MyMsg__Sequence
{
  zch_pkg__msg__MyMsg * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} zch_pkg__msg__MyMsg__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__STRUCT_H_
