// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__BUILDER_HPP_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "zch_pkg/msg/detail/my_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace zch_pkg
{

namespace msg
{

namespace builder
{

class Init_MyMsg_score
{
public:
  explicit Init_MyMsg_score(::zch_pkg::msg::MyMsg & msg)
  : msg_(msg)
  {}
  ::zch_pkg::msg::MyMsg score(::zch_pkg::msg::MyMsg::_score_type arg)
  {
    msg_.score = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::msg::MyMsg msg_;
};

class Init_MyMsg_age
{
public:
  explicit Init_MyMsg_age(::zch_pkg::msg::MyMsg & msg)
  : msg_(msg)
  {}
  Init_MyMsg_score age(::zch_pkg::msg::MyMsg::_age_type arg)
  {
    msg_.age = std::move(arg);
    return Init_MyMsg_score(msg_);
  }

private:
  ::zch_pkg::msg::MyMsg msg_;
};

class Init_MyMsg_name
{
public:
  Init_MyMsg_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MyMsg_age name(::zch_pkg::msg::MyMsg::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_MyMsg_age(msg_);
  }

private:
  ::zch_pkg::msg::MyMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::msg::MyMsg>()
{
  return zch_pkg::msg::builder::Init_MyMsg_name();
}

}  // namespace zch_pkg

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__BUILDER_HPP_
