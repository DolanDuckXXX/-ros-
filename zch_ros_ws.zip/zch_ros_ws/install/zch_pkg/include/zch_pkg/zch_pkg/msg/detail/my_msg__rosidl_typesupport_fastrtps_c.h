// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice
#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "zch_pkg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_zch_pkg
size_t get_serialized_size_zch_pkg__msg__MyMsg(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_zch_pkg
size_t max_serialized_size_zch_pkg__msg__MyMsg(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_zch_pkg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, zch_pkg, msg, MyMsg)();

#ifdef __cplusplus
}
#endif

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
