// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_H_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "zch_pkg/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_zch_pkg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  zch_pkg,
  msg,
  MyMsg
)();

#ifdef __cplusplus
}
#endif

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_H_
