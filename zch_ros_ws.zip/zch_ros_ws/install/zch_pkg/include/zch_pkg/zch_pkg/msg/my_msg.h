// generated from rosidl_generator_c/resource/idl.h.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__MY_MSG_H_
#define ZCH_PKG__MSG__MY_MSG_H_

#include "zch_pkg/msg/detail/my_msg__struct.h"
#include "zch_pkg/msg/detail/my_msg__functions.h"
#include "zch_pkg/msg/detail/my_msg__type_support.h"

#endif  // ZCH_PKG__MSG__MY_MSG_H_
