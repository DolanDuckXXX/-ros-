// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__TRAITS_HPP_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "zch_pkg/msg/detail/my_msg__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace zch_pkg
{

namespace msg
{

inline void to_flow_style_yaml(
  const MyMsg & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: age
  {
    out << "age: ";
    rosidl_generator_traits::value_to_yaml(msg.age, out);
    out << ", ";
  }

  // member: score
  {
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MyMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: age
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "age: ";
    rosidl_generator_traits::value_to_yaml(msg.age, out);
    out << "\n";
  }

  // member: score
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MyMsg & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace zch_pkg

namespace rosidl_generator_traits
{

[[deprecated("use zch_pkg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const zch_pkg::msg::MyMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  zch_pkg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use zch_pkg::msg::to_yaml() instead")]]
inline std::string to_yaml(const zch_pkg::msg::MyMsg & msg)
{
  return zch_pkg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<zch_pkg::msg::MyMsg>()
{
  return "zch_pkg::msg::MyMsg";
}

template<>
inline const char * name<zch_pkg::msg::MyMsg>()
{
  return "zch_pkg/msg/MyMsg";
}

template<>
struct has_fixed_size<zch_pkg::msg::MyMsg>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<zch_pkg::msg::MyMsg>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<zch_pkg::msg::MyMsg>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__TRAITS_HPP_
