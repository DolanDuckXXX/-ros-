// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from zch_pkg:msg/MyMsg.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_HPP_
#define ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "zch_pkg/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_zch_pkg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  zch_pkg,
  msg,
  MyMsg
)();
#ifdef __cplusplus
}
#endif

#endif  // ZCH_PKG__MSG__DETAIL__MY_MSG__TYPE_SUPPORT_HPP_
