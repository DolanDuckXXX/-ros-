// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from zch_pkg:srv/AddThreeInts.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__SRV__DETAIL__ADD_THREE_INTS__BUILDER_HPP_
#define ZCH_PKG__SRV__DETAIL__ADD_THREE_INTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "zch_pkg/srv/detail/add_three_ints__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace zch_pkg
{

namespace srv
{

namespace builder
{

class Init_AddThreeInts_Request_c
{
public:
  explicit Init_AddThreeInts_Request_c(::zch_pkg::srv::AddThreeInts_Request & msg)
  : msg_(msg)
  {}
  ::zch_pkg::srv::AddThreeInts_Request c(::zch_pkg::srv::AddThreeInts_Request::_c_type arg)
  {
    msg_.c = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::srv::AddThreeInts_Request msg_;
};

class Init_AddThreeInts_Request_b
{
public:
  explicit Init_AddThreeInts_Request_b(::zch_pkg::srv::AddThreeInts_Request & msg)
  : msg_(msg)
  {}
  Init_AddThreeInts_Request_c b(::zch_pkg::srv::AddThreeInts_Request::_b_type arg)
  {
    msg_.b = std::move(arg);
    return Init_AddThreeInts_Request_c(msg_);
  }

private:
  ::zch_pkg::srv::AddThreeInts_Request msg_;
};

class Init_AddThreeInts_Request_a
{
public:
  Init_AddThreeInts_Request_a()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AddThreeInts_Request_b a(::zch_pkg::srv::AddThreeInts_Request::_a_type arg)
  {
    msg_.a = std::move(arg);
    return Init_AddThreeInts_Request_b(msg_);
  }

private:
  ::zch_pkg::srv::AddThreeInts_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::srv::AddThreeInts_Request>()
{
  return zch_pkg::srv::builder::Init_AddThreeInts_Request_a();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace srv
{

namespace builder
{

class Init_AddThreeInts_Response_sum
{
public:
  Init_AddThreeInts_Response_sum()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::zch_pkg::srv::AddThreeInts_Response sum(::zch_pkg::srv::AddThreeInts_Response::_sum_type arg)
  {
    msg_.sum = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::srv::AddThreeInts_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::srv::AddThreeInts_Response>()
{
  return zch_pkg::srv::builder::Init_AddThreeInts_Response_sum();
}

}  // namespace zch_pkg

#endif  // ZCH_PKG__SRV__DETAIL__ADD_THREE_INTS__BUILDER_HPP_
