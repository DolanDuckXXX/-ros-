// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from zch_pkg:action/CountUntil.idl
// generated code does not contain a copyright notice

#ifndef ZCH_PKG__ACTION__DETAIL__COUNT_UNTIL__BUILDER_HPP_
#define ZCH_PKG__ACTION__DETAIL__COUNT_UNTIL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "zch_pkg/action/detail/count_until__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_Goal_target
{
public:
  Init_CountUntil_Goal_target()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::zch_pkg::action::CountUntil_Goal target(::zch_pkg::action::CountUntil_Goal::_target_type arg)
  {
    msg_.target = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_Goal>()
{
  return zch_pkg::action::builder::Init_CountUntil_Goal_target();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_Result_success
{
public:
  Init_CountUntil_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::zch_pkg::action::CountUntil_Result success(::zch_pkg::action::CountUntil_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_Result>()
{
  return zch_pkg::action::builder::Init_CountUntil_Result_success();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_Feedback_current_number
{
public:
  Init_CountUntil_Feedback_current_number()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::zch_pkg::action::CountUntil_Feedback current_number(::zch_pkg::action::CountUntil_Feedback::_current_number_type arg)
  {
    msg_.current_number = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_Feedback>()
{
  return zch_pkg::action::builder::Init_CountUntil_Feedback_current_number();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_SendGoal_Request_goal
{
public:
  explicit Init_CountUntil_SendGoal_Request_goal(::zch_pkg::action::CountUntil_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::zch_pkg::action::CountUntil_SendGoal_Request goal(::zch_pkg::action::CountUntil_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_SendGoal_Request msg_;
};

class Init_CountUntil_SendGoal_Request_goal_id
{
public:
  Init_CountUntil_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CountUntil_SendGoal_Request_goal goal_id(::zch_pkg::action::CountUntil_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_CountUntil_SendGoal_Request_goal(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_SendGoal_Request>()
{
  return zch_pkg::action::builder::Init_CountUntil_SendGoal_Request_goal_id();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_SendGoal_Response_stamp
{
public:
  explicit Init_CountUntil_SendGoal_Response_stamp(::zch_pkg::action::CountUntil_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::zch_pkg::action::CountUntil_SendGoal_Response stamp(::zch_pkg::action::CountUntil_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_SendGoal_Response msg_;
};

class Init_CountUntil_SendGoal_Response_accepted
{
public:
  Init_CountUntil_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CountUntil_SendGoal_Response_stamp accepted(::zch_pkg::action::CountUntil_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_CountUntil_SendGoal_Response_stamp(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_SendGoal_Response>()
{
  return zch_pkg::action::builder::Init_CountUntil_SendGoal_Response_accepted();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_GetResult_Request_goal_id
{
public:
  Init_CountUntil_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::zch_pkg::action::CountUntil_GetResult_Request goal_id(::zch_pkg::action::CountUntil_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_GetResult_Request>()
{
  return zch_pkg::action::builder::Init_CountUntil_GetResult_Request_goal_id();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_GetResult_Response_result
{
public:
  explicit Init_CountUntil_GetResult_Response_result(::zch_pkg::action::CountUntil_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::zch_pkg::action::CountUntil_GetResult_Response result(::zch_pkg::action::CountUntil_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_GetResult_Response msg_;
};

class Init_CountUntil_GetResult_Response_status
{
public:
  Init_CountUntil_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CountUntil_GetResult_Response_result status(::zch_pkg::action::CountUntil_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_CountUntil_GetResult_Response_result(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_GetResult_Response>()
{
  return zch_pkg::action::builder::Init_CountUntil_GetResult_Response_status();
}

}  // namespace zch_pkg


namespace zch_pkg
{

namespace action
{

namespace builder
{

class Init_CountUntil_FeedbackMessage_feedback
{
public:
  explicit Init_CountUntil_FeedbackMessage_feedback(::zch_pkg::action::CountUntil_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::zch_pkg::action::CountUntil_FeedbackMessage feedback(::zch_pkg::action::CountUntil_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_FeedbackMessage msg_;
};

class Init_CountUntil_FeedbackMessage_goal_id
{
public:
  Init_CountUntil_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CountUntil_FeedbackMessage_feedback goal_id(::zch_pkg::action::CountUntil_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_CountUntil_FeedbackMessage_feedback(msg_);
  }

private:
  ::zch_pkg::action::CountUntil_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::zch_pkg::action::CountUntil_FeedbackMessage>()
{
  return zch_pkg::action::builder::Init_CountUntil_FeedbackMessage_goal_id();
}

}  // namespace zch_pkg

#endif  // ZCH_PKG__ACTION__DETAIL__COUNT_UNTIL__BUILDER_HPP_
