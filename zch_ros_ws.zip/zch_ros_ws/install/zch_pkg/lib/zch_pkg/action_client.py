#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from zch_pkg.action import CountUntil


class CountUntilActionClient(Node):
    def __init__(self):
        super().__init__('count_until_action_client')
        self._action_client = ActionClient(self, CountUntil, 'count_until')

    def send_goal(self, target):
        goal_msg = CountUntil.Goal()
        goal_msg.target = target

        self._action_client.wait_for_server()
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected')
            return

        self.get_logger().info('Goal accepted')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f'Feedback: {feedback.current_number}')

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Result: success={result.success}')
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = CountUntilActionClient()

    target = 5
    if len(sys.argv) > 1:
        target = int(sys.argv[1])

    node.send_goal(target)
    rclpy.spin(node)


if __name__ == '__main__':
    main()
    
