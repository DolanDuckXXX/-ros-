#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from zch_pkg.msg import MyMsg


class MyMsgSubscriber(Node):
    def __init__(self):
        super().__init__('mymsg_subscriber')
        self.subscription = self.create_subscription(
            MyMsg,
            'student_info',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        self.get_logger().info(
            f'Received: name={msg.name}, age={msg.age}, score={msg.score}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = MyMsgSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
