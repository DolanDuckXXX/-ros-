#!/usr/bin/env python3
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from zch_pkg.action import CountUntil


class CountUntilActionServer(Node):
    def __init__(self):
        super().__init__('count_until_action_server')
        self._action_server = ActionServer(
            self,
            CountUntil,
            'count_until',
            self.execute_callback
        )
        self.get_logger().info('Action server is ready.')

    def execute_callback(self, goal_handle):
        self.get_logger().info(f'Received goal: target={goal_handle.request.target}')

        feedback_msg = CountUntil.Feedback()

        for i in range(1, goal_handle.request.target + 1):
            feedback_msg.current_number = i
            goal_handle.publish_feedback(feedback_msg)
            self.get_logger().info(f'Feedback: current_number={i}')
            time.sleep(1)

        goal_handle.succeed()

        result = CountUntil.Result()
        result.success = True
        return result


def main(args=None):
    rclpy.init(args=args)
    node = CountUntilActionServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
