#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from zch_pkg.msg import MyMsg


class MyMsgPublisher(Node):
    def __init__(self):
        super().__init__('mymsg_publisher')
        self.publisher_ = self.create_publisher(MyMsg, 'student_info', 10)
        self.timer = self.create_timer(1.0, self.publish_msg)
        self.count = 0

    def publish_msg(self):
        msg = MyMsg()
        msg.name = 'zch'
        msg.age = 20 + self.count
        msg.score = 95.5 + self.count
        self.publisher_.publish(msg)
        self.get_logger().info(
            f'Publishing: name={msg.name}, age={msg.age}, score={msg.score}'
        )
        self.count += 1


def main(args=None):
    rclpy.init(args=args)
    node = MyMsgPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
