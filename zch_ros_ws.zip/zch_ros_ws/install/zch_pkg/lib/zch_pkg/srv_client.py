#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from zch_pkg.srv import AddThreeInts


class AddThreeIntsClient(Node):
    def __init__(self):
        super().__init__('add_three_ints_client')
        self.client = self.create_client(AddThreeInts, 'add_three_ints')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting...')

    def send_request(self, a, b, c):
        req = AddThreeInts.Request()
        req.a = a
        req.b = b
        req.c = c
        return self.client.call_async(req)


def main(args=None):
    rclpy.init(args=args)
    node = AddThreeIntsClient()

    if len(sys.argv) != 4:
        node.get_logger().info('Usage: ros2 run zch_pkg srv_client.py a b c')
        return

    a = int(sys.argv[1])
    b = int(sys.argv[2])
    c = int(sys.argv[3])

    future = node.send_request(a, b, c)
    rclpy.spin_until_future_complete(node, future)

    if future.result() is not None:
        node.get_logger().info(f'Result: {future.result().sum}')
    else:
        node.get_logger().error('Service call failed.')

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
